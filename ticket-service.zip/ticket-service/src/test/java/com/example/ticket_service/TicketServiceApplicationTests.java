package com.example.ticket_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
