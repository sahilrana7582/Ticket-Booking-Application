package com.example.eureka_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
